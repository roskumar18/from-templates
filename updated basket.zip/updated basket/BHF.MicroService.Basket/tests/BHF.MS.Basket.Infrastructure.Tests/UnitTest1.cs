namespace BHF.MS.Basket.Infrastructure.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}