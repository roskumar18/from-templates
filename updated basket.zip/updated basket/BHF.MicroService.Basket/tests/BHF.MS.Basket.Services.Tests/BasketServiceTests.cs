using BHF.MS.Basket.Core.Interfaces;
using BHF.MS.Basket.Core.Models;
using BHF.MS.Basket.Services.Interfaces;
using Microsoft.Extensions.Logging;
using Moq;

namespace BHF.MS.Basket.Services.Tests
{
    public class BasketServiceTests
    {
        private readonly IBasketService _sut;
        private readonly Mock<IUnitOfWork> _unitOfWorkMock = new();
        private readonly Mock<ILogger<BasketService>> _loggerMock = new();

        public BasketServiceTests()
        {
            _sut = new BasketService(_loggerMock.Object, _unitOfWorkMock.Object);
        }

        private Core.Models.Basket CreateBasket(Guid id, List<BasketItem>? basketItems = null)
        {
            return new Core.Models.Basket
            {
                Id = id,
                BasketItems = basketItems ?? new List<BasketItem>()
            };
        }

        [Fact]
        public async Task CreateBasket_Successful()
        {
            // Arrange
            var basketDetails = new Core.Models.Basket { Id = Guid.NewGuid() };
            _unitOfWorkMock.Setup(u => u.Baskets.AddAsync(It.IsAny<Core.Models.Basket>())).ReturnsAsync(basketDetails);
            _unitOfWorkMock.Setup(u => u.SaveAsync()).ReturnsAsync(1);

            // Act
            var result = await _sut.CreateBasket(basketDetails);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public async Task CreateBasket_Failure()
        {
            // Arrange
            var basketDetails = new Core.Models.Basket { Id = Guid.NewGuid() };
            _unitOfWorkMock.Setup(u => u.Baskets.AddAsync(It.IsAny<Core.Models.Basket>())).ReturnsAsync(basketDetails);
            _unitOfWorkMock.Setup(u => u.SaveAsync()).ReturnsAsync(0); // Simulate save failure

            // Act
            var result = await _sut.CreateBasket(basketDetails);

            // Assert
            Assert.False(result);
        }

        [Fact]
        public async Task CreateBasket_ThrowsException_Failure()
        {
            // Arrange
            var basketDetails = new Core.Models.Basket { Id = Guid.NewGuid() };
            _unitOfWorkMock.Setup(u => u.Baskets.AddAsync(It.IsAny<Core.Models.Basket>())).ReturnsAsync(basketDetails);
            _unitOfWorkMock.Setup(u => u.SaveAsync()).Throws(new InvalidOperationException("Mocked exception")); // Simulate save failure

            // Act
            var result = await _sut.CreateBasket(basketDetails);

            // Assert
            // Assert

#pragma warning disable CS8602 // Dereference of a possibly null reference.
#pragma warning disable CS8620 // Argument cannot be used for parameter due to differences in the nullability of reference types.
            _loggerMock.Verify(logger => logger.Log(
          It.Is<LogLevel>(logLevel => logLevel == LogLevel.Error),
          It.Is<EventId>(eventId => eventId.Id == 0),
          It.Is<It.IsAnyType>((@object, @type) => @object.ToString()
          .StartsWith("Some error occured while creating basket") && @type.Name == "FormattedLogValues"),
          It.IsAny<Exception>(),
          It.IsAny<Func<It.IsAnyType, Exception, string>>()),
      Times.Once);
#pragma warning restore CS8620 // Argument cannot be used for parameter due to differences in the nullability of reference types.
#pragma warning restore CS8602 // Dereference of a possibly null reference.

            Assert.False(result);
        }

        [Fact]
        public async Task AddBasketItem_Failure()
        {
            // Arrange
            var basketId = Guid.NewGuid();
            _unitOfWorkMock.Setup(u => u.Baskets.GetBasketWithBasketItemsAsync(basketId)).ReturnsAsync((Core.Models.Basket)null); // Simulate basket not found

            // Act
            var result = await _sut.AddBasketItem(basketId, new BasketItem() { Id = Guid.NewGuid() });

            // Assert
            Assert.False(result);
        }
    }
}