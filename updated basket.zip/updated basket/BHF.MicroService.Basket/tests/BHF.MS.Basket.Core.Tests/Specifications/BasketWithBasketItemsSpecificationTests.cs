﻿using BHF.MS.Basket.Core.Specifications;
using System.Linq.Expressions;

namespace BHF.MS.Basket.Core.Tests.Specifications
{
    public class BasketWithBasketItemsSpecificationTests
    {
        private readonly List<Guid> TestBasketIds = new()
        { new Guid("47f1afd3-9f45-4638-8a79-7eb058458db8"),
            new Guid("f75ba293-c3b6-4b5b-9cbe-43c34f9d35a8"),
        };

        [Fact]
        public void BasketWithBasketItemsSpecification_Tests()
        {
            //Arrange
            Expression<Func<Core.Models.Basket, Object>> expectedInclude = b => b.BasketItems;
            //Act
            var spec = new BasketWithBasketItemsSpecification(TestBasketIds[0]);

            //Assert
            Assert.NotNull(spec);
            Assert.True(spec.Criteria.Parameters.Count == 1);
            Assert.True(spec.Includes.Count == 1);
            Assert.Equal(expectedInclude.Body.ToString(), spec.Includes[0].Body.ToString());
        }
    }
}
