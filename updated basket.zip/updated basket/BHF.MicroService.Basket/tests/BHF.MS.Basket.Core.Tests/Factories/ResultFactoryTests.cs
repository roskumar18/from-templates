﻿using BHF.MS.Basket.Core.Factories;

namespace BHF.MS.Basket.Core.Tests.Factories
{
    public class ResultFactoryTests
    {
        [Fact]
        public void Success_ShouldCreateSuccessResult()
        {
            // Arrange
            const string value = "test value";

            // Act
            Models.Result<string> result = ResultFactory.Success(value);

            // Assert
            Assert.True(result.IsSuccess);
            Assert.Equal(value, result.Value);
            Assert.Equal(string.Empty, result.Error);
        }

        [Fact]
        public void Failure_ShouldCreateFailureResult()
        {
            // Arrange
            const string error = "test error";

            // Act
            Models.Result<string> result = ResultFactory.Failure<string>(error);

            // Assert
            Assert.False(result.IsSuccess);
            Assert.Null(result.Value); // default value for string in Failure case
            Assert.Equal(error, result.Error);
        }
    }
}
