﻿using BHF.MS.Basket.Core.Enum;
using BHF.MS.Basket.Core.Factories;
using BHF.MS.Basket.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace BHF.MS.Basket.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BasketController : ControllerBase
    {
        private readonly IBasketService _basketService;
        private readonly ILogger<BasketController> _logger;
        public BasketController(IBasketService basketService, ILogger<BasketController> logger)
        {
            _basketService = basketService;
            _logger = logger;
        }

        [HttpGet("GetBasket/{basketId}")]
        public async Task<IActionResult> GetBasketById(Guid basketId)
        {
            try
            {
                var basketDetails = await _basketService.GetBasketById(basketId);

                if (basketDetails != null)
                {
                    var result = ResultFactory.Success(basketDetails);
                    return Ok(result);
                }
                else
                {
                    var result = ResultFactory.Failure<Core.Models.Basket>($"Could not find basket details for basket id {basketId}");
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in {method}, {error}", nameof(GetBasketById), ex);
                var result = ResultFactory.Failure<Core.Models.Basket>($"Some error occured while getting data for BasketID: {basketId}");
                return BadRequest(result);
            }
        }

        [HttpPost("CreateOrUpdateBasket")]
        public async Task<IActionResult> CreateOrUpdateBasket(Core.Models.Basket basketDetails)
        {
            try
            {
                var basketProcessStatus = await _basketService.CreateOrUpdateBasket(basketDetails);

                if (basketProcessStatus != EntityProcessStatus.Failed)
                {
                    var result = ResultFactory.Success(basketProcessStatus);
                    return Ok(result);
                }
                else
                {
                    var result = ResultFactory.Failure<EntityProcessStatus>("Basket update or create failed");
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in {method}, {error}", nameof(CreateOrUpdateBasket), ex);
                var result = ResultFactory.Failure<EntityProcessStatus>($"Some error occured while getting data for Basket details : {JsonSerializer.Serialize(basketDetails)}");
                return BadRequest(result);
            }
        }

        [HttpPost("DeleteBasket")]
        public async Task<IActionResult> DeleteBasket(Guid id)
        {
            try
            {
                var isBasketDeleted = await _basketService.DeleteBasket(id);

                if (isBasketDeleted)
                {
                    var result = ResultFactory.Success(EntityProcessStatus.Deleted);
                    return Ok(result);
                }
                else
                {
                    var result = ResultFactory.Failure<EntityProcessStatus>("Basket deletion failed");
                    return BadRequest(result);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in {method}, {error}", nameof(DeleteBasket), ex);
                var result = ResultFactory.Failure<EntityProcessStatus>($"Some error occured while deleting for Basket ID : {id}");
                return BadRequest(result);
            }
        }
    }
}
