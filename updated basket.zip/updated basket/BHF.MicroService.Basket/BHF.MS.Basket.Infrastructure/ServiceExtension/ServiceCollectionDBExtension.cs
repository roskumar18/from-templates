﻿using BHF.MS.Basket.Core.Interfaces;
using BHF.MS.Basket.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace BHF.MS.Basket.Infrastructure.ServiceExtension
{
    public static class ServiceCollectionDBExtension
    {
        private const string CustomDBConnectionName = "CustomDBConnection";

        public static IServiceCollection AddDBDependencies(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CustomContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString(CustomDBConnectionName));
            });
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IBasketRepository, BasketRepository>();
            services.AddScoped<IBasketItemsRepository, BasketItemsRepository>();

            return services;
        }
    }
}
