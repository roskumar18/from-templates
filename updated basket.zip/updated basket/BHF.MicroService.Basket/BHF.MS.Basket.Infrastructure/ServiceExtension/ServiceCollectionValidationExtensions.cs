﻿using BHF.MS.Basket.Core.Factories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.DependencyInjection;
using System.ComponentModel;
using System.Dynamic;
using System.Text.Json;

namespace BHF.MS.Basket.Infrastructure.ServiceExtension
{
    public static class ServiceCollectionValidationExtensions
    {
        public static IServiceCollection UseCoreAppCustomModelValidation(this IServiceCollection services)
        {
            services.Configure((Action<ApiBehaviorOptions>)(apiBehaviorOptions =>
                     apiBehaviorOptions.InvalidModelStateResponseFactory = actionContext =>
                     {
                         var message = GetModelStateFriendlyError(actionContext);

                         return new BadRequestObjectResult(ResultFactory.Failure<object>(JsonSerializer.Serialize(message)));
                     }));
            return services;
        }

        private static ExpandoObject GetModelStateFriendlyError(ActionContext actionContext)
        {
            var modelType = actionContext.ActionDescriptor.Parameters.FirstOrDefault()?.ParameterType;

            var expandoObj = new ExpandoObject();
            var expandoObjCollection = expandoObj as ICollection<KeyValuePair<string, object>>;

            var dictionary = actionContext.ModelState.ToDictionary(k => k.Key, v => v.Value)
                .Where(v => v.Value.ValidationState == ModelValidationState.Invalid)
                .ToDictionary(
                k =>
                {
                    if (modelType != null)
                    {
                        var property = Array.Find(modelType.GetProperties(), p => p.Name.Equals(k.Key, StringComparison.InvariantCultureIgnoreCase));
                        if (property != null)
                        {
                            //Try to get the attribute  
                            var displayName = property.GetCustomAttributes(typeof(DisplayNameAttribute), true).Cast<DisplayNameAttribute>().SingleOrDefault()?.DisplayName;
                            return displayName ?? property.Name;
                        }
                    }
                    return k.Key; //Nothing found, return original validation key  
                },
                v => v.Value.Errors.Select(e => e.ErrorMessage).ToList() as object); //Box String collection

            foreach (var keyValuePair in dictionary)
            {
                expandoObjCollection.Add(keyValuePair);
            }

            return expandoObj;
        }
    }
}
