﻿using BHF.MS.Basket.Core.Interfaces;

namespace BHF.MS.Basket.Infrastructure.Repositories
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly CustomContext _dbContext;
        public IBasketItemsRepository BasketItems { get; }
        public IBasketRepository Baskets { get; }

        public UnitOfWork(CustomContext dbContext, IBasketRepository basketRepository, IBasketItemsRepository basketItemsRepository)
        {
            _dbContext = dbContext;
            BasketItems = basketItemsRepository;
            Baskets = basketRepository;
        }

        public int Save()
        {
            return _dbContext.SaveChanges();
        }

        public Task<int> SaveAsync()
        {
            return _dbContext.SaveChangesAsync();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _dbContext.Dispose();
            }
        }
    }
}
