﻿using BHF.MS.Basket.Core.Interfaces;
using BHF.MS.Basket.Core.Models;
using BHF.MS.Basket.Infrastructure.Repositories.Base;

namespace BHF.MS.Basket.Infrastructure.Repositories
{
    public class BasketItemsRepository : GenericRepository<BasketItem, Guid>, IBasketItemsRepository
    {
        public BasketItemsRepository(CustomContext dbContext) : base(dbContext)
        {
        }
    }
}
