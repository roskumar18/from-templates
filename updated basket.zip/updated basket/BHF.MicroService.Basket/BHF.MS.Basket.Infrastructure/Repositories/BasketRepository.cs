﻿using BHF.MS.Basket.Core.Interfaces;
using BHF.MS.Basket.Core.Specifications;
using BHF.MS.Basket.Infrastructure.Repositories.Base;

namespace BHF.MS.Basket.Infrastructure.Repositories
{
    public class BasketRepository : GenericRepository<Core.Models.Basket, Guid>, IBasketRepository
    {
        public BasketRepository(CustomContext dbContext) : base(dbContext)
        {
        }

        public async Task<Core.Models.Basket?> GetBasketWithBasketItemsAsync(Guid id)
        {
            var spec = new BasketWithBasketItemsSpecification(id);
            IReadOnlyCollection<Core.Models.Basket> baskets = await GetAsync(spec);
            return baskets.FirstOrDefault();
        }

        public override void Update(Core.Models.Basket basketDetails, Core.Models.Basket updatedBasketDetails)
        {
            updatedBasketDetails.LastUpdatedDate = DateTime.UtcNow;
            _dbContext.Entry(basketDetails).CurrentValues.SetValues(updatedBasketDetails);
            _dbContext.Set<Core.Models.Basket>().Attach(basketDetails);
            _dbContext.Entry(basketDetails).Property(x => x.OrderRef).IsModified = false;
            _dbContext.Entry(basketDetails).Property(x => x.CreatedDate).IsModified = false;
        }
    }
}
