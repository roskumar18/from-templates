﻿using BHF.MS.Basket.Core.Models;
using Microsoft.EntityFrameworkCore;

namespace BHF.MS.Basket.Infrastructure
{
    public class CustomContext : DbContext
    {
        public CustomContext(DbContextOptions<CustomContext> contextOptions) : base(contextOptions)
        {
        }

        public virtual DbSet<Core.Models.Basket> Baskets { get; set; }
        public virtual DbSet<BasketItem> BasketItems { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Core.Models.Basket>()
               .HasMany(e => e.BasketItems)
               .WithOne(e => e.Basket)
               .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<BasketItem>()
                .HasIndex(x => x.BasketId);
        }
    }
}
