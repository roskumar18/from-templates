﻿namespace BHF.MS.Basket.Core.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        IBasketRepository Baskets { get; }
        IBasketItemsRepository BasketItems { get; }
        int Save();
        Task<int> SaveAsync();
    }
}
