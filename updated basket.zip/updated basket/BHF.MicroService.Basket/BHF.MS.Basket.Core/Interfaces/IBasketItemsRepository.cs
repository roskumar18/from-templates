﻿using BHF.MS.Basket.Core.Models;

namespace BHF.MS.Basket.Core.Interfaces
{
    public interface IBasketItemsRepository : IGenericRepository<BasketItem, Guid>
    {
    }
}
