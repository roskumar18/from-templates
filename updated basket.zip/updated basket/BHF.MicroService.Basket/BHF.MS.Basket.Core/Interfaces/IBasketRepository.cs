﻿namespace BHF.MS.Basket.Core.Interfaces
{
    public interface IBasketRepository : IGenericRepository<Core.Models.Basket, Guid>
    {
        Task<Core.Models.Basket?> GetBasketWithBasketItemsAsync(Guid id);
    }
}
