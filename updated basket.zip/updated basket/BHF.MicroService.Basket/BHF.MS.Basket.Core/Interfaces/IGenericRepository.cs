﻿using BHF.MS.Basket.Core.Specifications.Base;
using System.Linq.Expressions;

namespace BHF.MS.Basket.Core.Interfaces
{
    public interface IGenericRepository<T, TId> where T : class
    {
        Task<IReadOnlyList<T>> GetAllAsync();
        Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>> predicate);
        Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null,
                                        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
                                        string? includeString = null,
                                        bool disableTracking = true);
        Task<IReadOnlyList<T>> GetAsync(Expression<Func<T, bool>>? predicate = null,
                                        Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
                                        List<Expression<Func<T, object>>>? includes = null,
                                        bool disableTracking = true);
        Task<IReadOnlyList<T>> GetAsync(ISpecification<T> spec);
        Task<T?> GetByIdAsync(TId id);
        Task<T> AddAsync(T entity);
        Task<IEnumerable<T>> AddAllAsync(IEnumerable<T> entities);
        void Update(T entity);
        void Update(T entity, T updatedEntity);
        void DeleteAll(IEnumerable<T> entities);
        void Delete(T entity);
        Task<int> CountAsync(ISpecification<T> spec);
    }
}
