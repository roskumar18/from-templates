using BHF.MS.Basket.Core.Models;

namespace BHF.MS.Basket.Core.Factories
{
    public static class ResultFactory
    {
        public static Result<T> Success<T>(T value) => new(value, true, string.Empty);
        public static Result<T> Failure<T>(string error) => new(default, false, error);
    }
}
