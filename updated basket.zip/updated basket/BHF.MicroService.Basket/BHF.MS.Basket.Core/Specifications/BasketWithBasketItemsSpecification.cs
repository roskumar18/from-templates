﻿using BHF.MS.Basket.Core.Specifications.Base;

namespace BHF.MS.Basket.Core.Specifications
{
    public sealed class BasketWithBasketItemsSpecification : BaseSpecification<Core.Models.Basket>
    {
        public BasketWithBasketItemsSpecification(Guid id)
            : base(b => b.Id == id)
        {
            AddInclude(b => b.BasketItems);
        }
    }
}
