﻿namespace BHF.MS.Basket.Core.Enum
{
    public enum EntityProcessStatus
    {
        Failed,
        Inserted,
        Updated,
        Deleted
    }
}
