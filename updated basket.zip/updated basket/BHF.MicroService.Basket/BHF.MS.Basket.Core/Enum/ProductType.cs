﻿namespace BHF.MS.Basket.Core.Enum
{
    public enum ProductType : int
    {
        Publication = 0,
        Donation = 1,
        Engraving = 2,
        MyBhf = 3
    }
}
