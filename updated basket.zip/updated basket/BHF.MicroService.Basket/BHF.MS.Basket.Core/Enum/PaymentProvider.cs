﻿namespace BHF.MS.Basket.Core.Enum
{
    public enum PaymentProvider
    {
        Worldpay,
        PayPal,
        DirectDebit
    }
}
