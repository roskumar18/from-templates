﻿namespace BHF.MS.Basket.Core.Enum
{
    public enum PaymentStatus
    {
        Pending = 0,
        Complete = 1,
        Done = 2,
        Refused = 3
    }
}
