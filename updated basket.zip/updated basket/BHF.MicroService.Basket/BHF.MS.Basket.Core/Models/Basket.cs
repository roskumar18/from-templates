﻿using BHF.MS.Basket.Core.Enum;
using BHF.MS.Basket.Core.Models.Base;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BHF.MS.Basket.Core.Models
{
    [Serializable]
    public class Basket : Entity<Guid>
    {
        public Basket()
        {
            BasketItems = new HashSet<BasketItem>();
        }

        public Guid? OrderId { get; set; }

        public Guid? UserId { get; set; }

        public int? Quantity { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        [Required]
        public decimal Total { get; set; }

        public PaymentProvider? PaymentProvider { get; set; }

        public PaymentStatus? PaymentStatus { get; set; }

        [Required]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderRef { get; internal set; }

        public virtual ICollection<BasketItem> BasketItems { get; set; }
    }
}
