﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BHF.MS.Basket.Core.Models.Base
{
    public abstract class Entity<T>
    {
        private DateTime? _createdDate;

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public virtual required T Id { get; set; }

        [DataType(DataType.DateTime)]
        public DateTime CreatedDate
        {
            get { return _createdDate ?? DateTime.Now; }
            set { _createdDate = value; }
        }

        [DataType(DataType.DateTime)]
        public DateTime? LastUpdatedDate { get; set; }
    }
}
