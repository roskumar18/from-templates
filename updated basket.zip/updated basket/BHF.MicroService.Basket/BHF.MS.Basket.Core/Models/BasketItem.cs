﻿using BHF.MS.Basket.Core.Enum;
using BHF.MS.Basket.Core.Models.Base;
using System.ComponentModel.DataAnnotations;

namespace BHF.MS.Basket.Core.Models
{
    [Serializable]
    public class BasketItem : Entity<Guid>
    {
        [Required]
        public Guid BasketId { get; set; }

        [Required]
        public Guid ProductId { get; set; }

        public ProductType ProductType { get; set; }

        [StringLength(500)]
        public string? Name { get; set; }

        public int Quantity { get; set; }

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(4000)]
        public string? Properties { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public decimal SubTotal { get; set; }

        [Required]
        public bool IsRemovable { get; set; } = true;

        public virtual Basket? Basket { get; set; }
    }
}
