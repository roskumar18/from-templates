﻿using BHF.MS.Basket.Core.Enum;
using BHF.MS.Basket.Core.Models;

namespace BHF.MS.Basket.Services.Interfaces
{
    public interface IBasketService
    {
        Task<bool> CreateBasket(Core.Models.Basket basketDetails);
        Task<EntityProcessStatus> CreateOrUpdateBasket(Core.Models.Basket basketDetails);
        Task<Core.Models.Basket?> GetBasketById(Guid id);
        Task<bool> UpdateBasket(Core.Models.Basket updatedBasketDetails, Core.Models.Basket oldBasketDetails);
        Task<bool> DeleteBasket(Guid id);
        Task<bool> AddBasketItem(Guid basketId, BasketItem basketItem);
    }
}
