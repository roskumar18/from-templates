﻿using BHF.MS.Basket.Core.Enum;
using BHF.MS.Basket.Core.Interfaces;
using BHF.MS.Basket.Core.Models;
using BHF.MS.Basket.Services.Interfaces;
using Microsoft.Extensions.Logging;

namespace BHF.MS.Basket.Services
{
    public class BasketService : IBasketService
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ILogger<BasketService> _logger;

        public BasketService(ILogger<BasketService> logger, IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
            _logger = logger;
        }

        public async Task<bool> CreateBasket(Core.Models.Basket basketDetails)
        {
            try
            {
                if (basketDetails != null)
                {
                    await _unitOfWork.Baskets.AddAsync(basketDetails);

                    var result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured while creating basket {error}", ex);
                return false;
            }
        }

        public async Task<bool> DeleteBasket(Guid id)
        {
            try
            {
                var basketDetails = await _unitOfWork.Baskets.GetByIdAsync(id);
                if (basketDetails != null)
                {
                    _unitOfWork.Baskets.Delete(basketDetails);
                    var result = await _unitOfWork.SaveAsync();

                    if (result > 0)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in Deleting basket {error}", ex);
                return false;
            }
        }

        public async Task<Core.Models.Basket?> GetBasketById(Guid id)
        {
            try
            {
                var basketDetails = await _unitOfWork.Baskets.GetByIdAsync(id);
                return basketDetails;
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in getting basket by ID {error}", ex);
                return null;
            }
        }

        public async Task<EntityProcessStatus> CreateOrUpdateBasket(Core.Models.Basket basketDetails)
        {
            try
            {
                var existingBasket = await _unitOfWork.Baskets.GetBasketWithBasketItemsAsync(basketDetails.Id);
                if (existingBasket != null)
                {
                    return await UpdateBasket(basketDetails, existingBasket) ? EntityProcessStatus.Updated : EntityProcessStatus.Failed;
                }
                return await CreateBasket(basketDetails) ? EntityProcessStatus.Inserted : EntityProcessStatus.Failed;
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in {method}, {error}", nameof(CreateOrUpdateBasket), ex);
                return EntityProcessStatus.Failed;
            }
        }

        public async Task<bool> UpdateBasket(Core.Models.Basket updatedBasketDetails, Core.Models.Basket oldBasketDetails)
        {
            try
            {
                if (updatedBasketDetails.BasketItems?.Count > 0)
                {
                    _unitOfWork.BasketItems.DeleteAll(oldBasketDetails.BasketItems);
                    await _unitOfWork.BasketItems.AddAllAsync(updatedBasketDetails.BasketItems);
                }
                _unitOfWork.Baskets.Update(oldBasketDetails, updatedBasketDetails);
                return await _unitOfWork.SaveAsync() > 0;
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in {method}, {error}", nameof(UpdateBasket), ex);
                return false;
            }
        }

        public async Task<bool> AddBasketItem(Guid basketId, BasketItem basketItem)
        {
            try
            {
                var existingBasket = await _unitOfWork.Baskets.GetBasketWithBasketItemsAsync(basketId);
                if (existingBasket != null)
                {
                    existingBasket.BasketItems.Add(basketItem);
                    existingBasket.Quantity += basketItem.Quantity;
                    existingBasket.Total += basketItem.SubTotal;
                    return await _unitOfWork.SaveAsync() > 0;
                }
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("Some error occured in {method}, {error}", nameof(AddBasketItem), ex);
                return false;
            }
        }
    }
}
